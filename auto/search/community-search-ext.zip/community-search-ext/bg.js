// 다른 사이트 글을 대신 가져오는 백그라운드 (인스티즈 화면에서 더쿠 검색 등)
const OK = /^https:\/\/((www\.)?instiz\.net|theqoo\.net|binaroo-z\.github\.io)\//;
chrome.runtime.onMessage.addListener((m, sender, send) => {
  if (!m || !m.csFetch) return;
  if (!OK.test(m.csFetch)) { send({ ok: false, err: '허용 안 된 주소' }); return; }
  const ac = new AbortController(), tm = setTimeout(() => ac.abort(), 15000);
  const opt = m.post ? { method: 'POST', headers: m.head || {}, body: m.post, credentials: 'include', signal: ac.signal }
                     : { credentials: 'include', signal: ac.signal };
  fetch(m.csFetch, opt)
    .then(async (r) => send({ ok: r.ok, status: r.status, text: r.ok ? await r.text() : '' }))
    .catch((e) => send({ ok: false, err: e.name === 'AbortError' ? '시간초과' : '접속 오류' }))
    .finally(() => clearTimeout(tm));
  return true; // 응답을 비동기로 보냄
});
