# TC 리뷰어 배포 파일

## 1. 홈페이지 게시용 — web/index.html
- 파일 하나로 동작합니다. 웹 서버(홈페이지)에 index.html을 올리면 끝입니다.
- 라이브러리(엑셀 읽기·쓰기, PDF, Word)는 cdnjs CDN에서 불러옵니다. 인터넷 연결이 필요합니다.
- AI 리뷰: 방문자가 본인의 Anthropic API 키를 넣어야 동작합니다. 키는 그 사람 브라우저에만 저장됩니다.
  사이트 운영자 키를 페이지에 넣으면 누구나 볼 수 있으니 절대 넣지 마세요.
- AI 없이 점검: 키 없이 바로 쓸 수 있습니다.

## 2. Windows 프로그램 — exe/TC-Reviewer-1.0.0-portable.exe
- 설치 없이 더블클릭으로 실행하는 포터블 프로그램입니다 (Windows 10/11, 64비트).
- 코드 서명이 없어 처음 실행 시 SmartScreen 경고가 뜰 수 있습니다: "추가 정보 → 실행".
- 라이브러리를 모두 포함해서 ‘AI 없이 점검’과 엑셀 내보내기는 오프라인으로도 됩니다.
- AI 리뷰는 API 키 입력 후 인터넷 연결이 필요합니다.

## 소스
- tc-review.html: 원본(claude.ai 아티팩트와 같은 파일)
- source/tc-reviewer-source.tar.gz: build.py(원본 → 웹/EXE용 HTML 생성), Electron 앱 소스
  다시 빌드: python3 build.py → exe 폴더에서 npm i → npx electron-builder --win portable --x64
